//
//  ZipArchive.h
//  ZipArchive
//
//  Created by Serhii Mumriak on 12/1/15.
//  Copyright © 2015 smumryak. All rights reserved.
//

#ifdef __OBJC__
#import <Foundation/Foundation.h>
#import <ZipArchive/SSZipArchive.h>
#endif
